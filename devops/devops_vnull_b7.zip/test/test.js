const chai = require('chai');
const supertest = require('supertest');
const expect = chai.expect;

const tatooine = {
    id: 1,
    nome: 'Tatooine',
    terreno: 'Areia',
    clima: 'Quente'
}

const yavinIV = {
    id: 3,
    nome: 'Yavin IV',
    terreno: 'Floresta',
    clima: 'Frio'
}

const request = supertest('http://localhost:3000/');
describe('Tests with empty database', () => {
    it('find by name', (done) => {
        request
            .get('planet/name/Tatooine')
            .expect(404)
            .end((err, res) => {
                done()
            })
    })
})
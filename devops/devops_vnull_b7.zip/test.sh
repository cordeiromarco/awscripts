#!/bin/sh
docker-compose build
docker-compose up -d
docker-compose exec app npm test
docker-compose down